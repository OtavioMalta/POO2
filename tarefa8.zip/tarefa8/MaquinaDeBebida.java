public abstract class MaquinaDeBebida{ 

    public abstract Bebida entregarBebida();

}