public class Suco implements Bebida{

    public String tipoBebida(){
        return "Suco";
    }
}