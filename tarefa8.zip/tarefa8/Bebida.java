public interface Bebida { 
    public String tipoBebida();
}
