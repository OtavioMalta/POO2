public class Refrigerante implements Bebida{ 

    
    public String tipoBebida(){
        return "Refrigerante";
    }
}