public class Cafe implements Bebida {

    @Override
    public String tipoBebida() {
        return "Cafe";
    }

    public Cafe(){
        
    }
    
}
